/*
 *CustomerDA - this file is contains all of the data access methods, that actually get/set data to the database.
 * @author Rut Patel
 * @version 3.0 (02 January 2021)
 * @since 1.0
 */
package webd4201.patelr;


import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StudentDA {


    static Student aStudent;

    // declare variables for the database connection
    static Connection aConnection;
    static Statement aStatement;

    // declare static variables for all Customer instance attribute values
    static String programCode ;
    static String programDescription ;
    static int year ;
    static long id;
    static String password;
    static String firstName;
    static String lastName;
    static String emailAddress;
    static Date lastAccess;
    static Date enrolDate;
    static boolean enabled;
    static char type;

    private static final SimpleDateFormat SQL_DF = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Establishing the connection.
     * @param c;
     */
    public static void initialize(Connection c)
    {
        try {
            aConnection=c;
            aStatement=aConnection.createStatement();
        }
        catch (SQLException e)
        {
            System.out.println(e);
        }
    }

    /**
     * close the database connection
     */
    public static void terminate()
    {
        try
        { 	// close the statement
            aStatement.close();
        }
        catch (SQLException e)
        { System.out.println(e);	}
    }

    /**
     * Retrieves the data by querying.
     * @param id;
     * @return Student
     * @throws NotFoundException if the data record is not found in the database.
     */
    public static Student retrieve(long id) throws NotFoundException
    {
        aStudent = null;

        String sqlQuery = "SELECT users.Id, Password, FirstName, LastName, EmailAddress, LastAccess,\n" +
                "EnrolDate, Enable, Type, ProgramCode, ProgramDescription, Year\n" +
                "FROM users, students WHERE users.id = students.StudentId AND users.Id ='" + id + "'";

        try {
            ResultSet rs = aStatement.executeQuery(sqlQuery);

            boolean gotData = rs.next();
            if (gotData) {
                password = rs.getString("Password");
                firstName = rs.getString("FirstName");
                lastName = rs.getString("LastName");
                emailAddress = rs.getString("EmailAddress");
                lastAccess = rs.getTimestamp("LastAccess");
                enrolDate = rs.getTimestamp("EnrolDate");
                programCode = rs.getString("ProgramCode");
                programDescription = rs.getString("ProgramDescription");
                year = rs.getInt("Year");
                enabled = rs.getBoolean("Enable");
                type = rs.getString("Type").charAt(0);

                try {
                    aStudent = new Student(id, password, firstName, lastName, emailAddress, enrolDate, lastAccess, enabled, type, programCode, programDescription, year);
                } catch (InvalidUserDataException e) {
                    System.out.println("Your record Contains some invalid Data.");
                }
            } else {
                throw (new NotFoundException("Problem retrieving Student record, with id: " + id + " does not exist in the system."));
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println(e);
        }

        return aStudent;
    }

    /**
     * Creates a record in the database.
     * @param aStudent;
     * @return boolean
     * @throws DuplicateException is thrown if the data is getting duplicated.
     */
    public static boolean create(Student aStudent) throws DuplicateException
    {
        boolean inserted = false;
        id = aStudent.getId();
        password = aStudent.getPassword();
        firstName = aStudent.getFirstName();
        lastName = aStudent.getLastName();
        emailAddress = aStudent.getEmailAddress();
        lastAccess = aStudent.getLastAccess();
        enrolDate = aStudent.getEnrolDate();
        programCode = aStudent.getProgramCode();
        programDescription = aStudent.getProgramDescription();
        year = aStudent.getYear();
        enabled = true;
        type = aStudent.getType();

        String sqlInsertUsers = "INSERT INTO users " +
                                "(Id, Password, FirstName, LastName, EmailAddress, LastAccess, EnrolDate, Enable,Type) " +
                "VALUES ('" + id + "', '" + password + "', '" + firstName + "','" + lastName + "','" + emailAddress + "','" + lastAccess + "','" + enrolDate + "','" + enabled + "','" + type +"')";

        String sqlInsertStudent = "INSERT INTO students " +
                                "(StudentId, ProgramCode, ProgramDescription, Year)" +
                            "VALUES ('" + id + "','" + programCode + "','" + programDescription+ "','" + year + "')";

        try
        {
            retrieve(id);
            throw(new DuplicateException("Problem with creating Student record, id: " + id +" already exists in the system."));
        }
        catch(NotFoundException e)
        {
            try
            {  // execute the SQL update statement
                inserted = aStatement.execute(sqlInsertUsers);
                inserted = aStatement.execute(sqlInsertStudent);
            }
            catch (SQLException ee)
            {
                System.out.println(ee);
            }
        }
        return inserted;
    }

    /**
     *Updates the selected record.
     * @param aStudent;
     * @return int
     * @throws NotFoundException;
     */
    public static int update(Student aStudent) throws NotFoundException
    {
        int records = 0;

        id = aStudent.getId();
        password = aStudent.getPassword();
        firstName = aStudent.getFirstName();
        lastName = aStudent.getLastName();
        emailAddress = aStudent.getEmailAddress();
        lastAccess = aStudent.getLastAccess();
        enrolDate = aStudent.getEnrolDate();
        programCode = aStudent.getProgramCode();
        programDescription = aStudent.getProgramDescription();
        year = aStudent.getYear();
        enabled = true;
        type = aStudent.getType();

        String sqlUpdateUsers = "UPDATE users " +
                                " SET Password      = '" + password +"', " +
                                " FirstName   = '" + firstName +"', " +
                                " LastName   = '" + lastName +"'," +
                                " EmailAddress   = '" + emailAddress +"', " +
                                " LastAccess   = '" + lastAccess +"' ," +
                                " EnrolDate   = '" + enrolDate +"', " +
                                " Enable   = '" + enabled +"', " +
                                " Type   = '" + type +"' " +
                                " WHERE Id = '" + id + "'";

        String sqlUpdateStudent = "UPDATE students " +
                                " SET ProgramCode  = '" + programCode +"', " +
                                " ProgramDescription   = '" + programDescription +"', " +
                                " Year   = '" + year +"' " +
                                " WHERE StudentId = '" + id + "'";
        // NotFoundException is thrown by find method
        try
        {
            Student.retrieve(id);  //determine if there is a Customer record to be updated
            // if found, execute the SQL update statement
            records = aStatement.executeUpdate(sqlUpdateStudent);
            records = aStatement.executeUpdate(sqlUpdateUsers);
        }catch(NotFoundException e)
        {
            throw new NotFoundException("Student with id " + id  + " cannot be updated, does not exist in the system.");
        }catch (SQLException e)
        { System.out.println(e);}
        return records;

    }

    /**
     * Deletes the selected record.
     * @param aStudent;
     * @return int
     * @throws NotFoundException if the data record is not found in the database
     */
    public static int delete(Student aStudent) throws NotFoundException
    {
        int records = 0;
        // retrieve the id (key)
        id = aStudent.getId();
        // create the SQL delete statement
        String sqlDeleteUsers = "DELETE FROM users " +
                "WHERE Id = '" + id +"'";

        String sqlDeleteStudents = "DELETE FROM students " +
                "WHERE StudentId = '" + id +"'";
        // see if this customer already exists in the database
        try
        {
            Student.retrieve(id);  //used to determine if record exists for the passed Customer
            // if found, execute the SQL update statement
            records = aStatement.executeUpdate(sqlDeleteStudents);
            records = aStatement.executeUpdate(sqlDeleteUsers);

        }catch(NotFoundException e)
        {
            throw new NotFoundException("Student with id " + id
                    + " cannot be deleted, does not exist.");
        }catch (SQLException e)
        { System.out.println(e);	}
        return records;
    }

}
